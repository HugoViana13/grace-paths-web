
# 🌟 Grace Paths — Caminhos de Sabedoria Firme

Este projeto é uma mandala interativa de caminhos espirituais universais para conduzir qualquer buscador ao estado de **Sabedoria Firme** (Sthitaprajna), conforme descrito em tradições como Vedanta, Budismo Tiantai, Taoísmo, Cristianismo Místico e Psicologia Transpessoal.

## 📌 Objetivo

Oferecer uma plataforma acessível e gratuita para guiar, inspirar e sustentar o despertar da consciência por diferentes vias — sempre em direção ao Centro.

## 📁 Estrutura

- `core/` — Modelos centrais do Caminho e Motor de Realização
- `data/` — Caminhos e tradições em formato YAML
- `ui/` — Interface HTML e selector interativo
- `mantras/` — Biblioteca de frases, práticas e sabedorias
- `tests/` — Testes para garantir coerência do caminho

## 🧘 Princípios Éticos

1. Não imposição: cada caminho é oferecido, nunca exigido.
2. Diversidade espiritual: todas as tradições são bem-vindas.
3. Privacidade interior: nenhuma coleta de dados do usuário.
4. Sabedoria encarnada: cada prática deve ser aplicável no cotidiano.
5. Silêncio como centro: o objetivo não é o saber, mas o Ser.

## 🚀 Como usar

1. Navegue pelos caminhos disponíveis.
2. Reflita sobre os diagnósticos oferecidos.
3. Pratique com constância e leveza.
4. Compartilhe, se ressoar — o Dharma é gratuito.

---

Desenvolvido com intenção de Graça para Todos 🌿
