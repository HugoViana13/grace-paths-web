
import streamlit as st
import json

st.set_page_config(page_title="Grace Paths Multilingue", layout="wide")
st.title("🌀 Grace Paths — Caminhos de Sabedoria Firme")

# Carregar caminhos multilíngues
with open("multilingual_paths.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Seletor de idioma
lang = st.selectbox("🌍 Escolha o idioma / Choose language", options=["pt", "en"], format_func=lambda l: "Português" if l=="pt" else "English")

paths = data[lang]
path_names = list(paths.keys())

# Seletor de caminho
selected_path = st.selectbox("🧭 Escolha um Caminho / Choose a Path", path_names)

st.subheader("🌱 Práticas / Practices")
for practice in paths[selected_path]["práticas" if lang == "pt" else "practices"]:
    st.markdown(f"- {practice}")

st.subheader("💡 Diagnóstico / Diagnostic")
st.info(paths[selected_path]["diagnóstico" if lang == "pt" else "diagnosis"])

st.markdown("---")
st.markdown("Desenvolvido com presença silenciosa e amor compartilhado.")
