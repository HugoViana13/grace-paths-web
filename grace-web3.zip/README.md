
# 🌐 Grace Paths Web — Interface Interativa para o Estado de Sabedoria Firme

Este projeto oferece uma experiência interativa para explorar diferentes **caminhos espirituais tradicionais** (como Vedanta, Budismo Tiantai, Taoísmo) que conduzem ao estado de **Sabedoria Firme (Sthitaprajna)** — um ser que age sem ego, ama sem apego e vive com presença profunda.

---

## 📦 Conteúdo

- `app.py` → Aplicativo interativo em Streamlit para diagnóstico e prática espiritual
- `mandala.html` → Protótipo visual de mandala dos caminhos espirituais

---

## 🚀 Como usar

### ✔️ Usar com Streamlit (Recomendado)

1. Crie uma conta gratuita em [https://streamlit.io/cloud](https://streamlit.io/cloud)
2. Conecte seu GitHub e selecione este repositório
3. Escolha `app.py` como ponto de entrada
4. Execute e compartilhe sua instância pública ✨

### ✔️ Usar com Vercel (Mandala Visual)

1. Vá para [https://vercel.com](https://vercel.com)
2. Clique em "New Project" e importe este repositório do GitHub
3. Configure `mandala.html` como entrada
4. Pronto! Você terá um link com a mandala pública

---

## 🌱 Caminhos Incluídos

- **Sthitaprajna (Vedanta)** — equanimidade e ação sem ego
- **Bodhisattva Compassivo (Tiantai)** — compaixão lúcida com sabedoria
- **Tao Fluente (Taoísmo)** — viver no fluxo do real, sem forçar

Cada caminho inclui práticas essenciais e um "diagnóstico de realização" para autoavaliação contemplativa.

---

## 🧘 Princípios Éticos

- 🕊️ Não imposição espiritual
- 🌿 Validação da diversidade interior
- 🔇 Centralidade do silêncio como sabedoria

---

## 🤝 Contribua

Quer adicionar novos caminhos, tradições ou práticas? Envie um pull request ou abra uma issue.

Com gratidão e presença,
> _Que todos os seres encontrem o seu caminho de graça silenciosa._

