
import streamlit as st
import yaml

st.set_page_config(page_title="Grace Paths", layout="wide")

st.title("🌀 Grace Paths — Caminhos de Sabedoria Firme")

st.markdown("Explore diferentes tradições espirituais e encontre seu caminho para a sabedoria lúcida e viva.")

# Carregar caminhos de exemplo
paths = {
    "Sthitaprajna (Vedanta)": {
        "práticas": ["Meditação em equanimidade", "Entrega dos frutos da ação", "Estudo dos Vedas com discernimento"],
        "diagnóstico": "Você espera algo em troca pela sua generosidade?"
    },
    "Bodhisattva Compassivo (Tiantai)": {
        "práticas": ["Meditação metta", "Ichinen Sanzen contemplativo", "Ação lúcida sem expectativa"],
        "diagnóstico": "Você vê sua dor no outro sem se apegar?"
    },
    "Tao Fluente (Taoísmo)": {
        "práticas": ["Contemplação da natureza", "Não-resistência ativa", "Wu wei cotidiano"],
        "diagnóstico": "Você sente que o mundo flui mesmo sem seu esforço?"
    }
}

path_name = st.selectbox("Escolha um Caminho", list(paths.keys()))

st.subheader("🌱 Práticas Essenciais")
for practice in paths[path_name]["práticas"]:
    st.markdown(f"- {practice}")

st.subheader("🧭 Diagnóstico de Realização")
st.info(paths[path_name]["diagnóstico"])

st.markdown("---")
st.markdown("Desenvolvido com amor, silêncio e sabedoria.")
